# 📅 Banco BartoTec 
<ul>
<li>Base de dados para a bartotec 2025</li>
<li>Cadastro para os alunos receberem atualizações relacionadas ao calendário do CPS </li>
</ul> 

