function limparCampos() {
    const campos = document.getElementById ('nome', 'email', 'tel', 'senha');
    campos.value = '';
}
